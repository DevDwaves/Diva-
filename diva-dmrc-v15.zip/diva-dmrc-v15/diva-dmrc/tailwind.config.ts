import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // DMRC Brand Colors — exact from design
        primary: "#b40006",
        "primary-container": "#da251d",
        "on-primary": "#ffffff",
        "on-primary-container": "#fff3f1",
        "primary-fixed": "#ffdad5",
        "primary-fixed-dim": "#ffb4a9",
        "on-primary-fixed": "#410001",
        "on-primary-fixed-variant": "#930004",
        "inverse-primary": "#ffb4a9",

        secondary: "#175ead",
        "secondary-container": "#72aafe",
        "on-secondary": "#ffffff",
        "on-secondary-container": "#003d79",
        "secondary-fixed": "#d5e3ff",
        "secondary-fixed-dim": "#a8c8ff",
        "on-secondary-fixed": "#001b3c",
        "on-secondary-fixed-variant": "#004689",

        tertiary: "#005b98",
        "tertiary-container": "#0074c0",
        "on-tertiary": "#ffffff",
        "on-tertiary-container": "#f2f6ff",
        "tertiary-fixed": "#d1e4ff",
        "tertiary-fixed-dim": "#9dcaff",
        "on-tertiary-fixed": "#001d36",
        "on-tertiary-fixed-variant": "#00497c",

        surface: "#fff8f7",
        "surface-dim": "#f3d3ce",
        "surface-bright": "#fff8f7",
        "surface-glass": "rgba(255, 255, 255, 0.7)",
        "surface-variant": "#fcdbd6",
        "surface-container": "#ffe9e6",
        "surface-container-low": "#fff0ee",
        "surface-container-high": "#ffe2dd",
        "surface-container-highest": "#fcdbd6",
        "surface-container-lowest": "#ffffff",
        "surface-tint": "#bf080b",

        "on-surface": "#281715",
        "on-surface-variant": "#5d403b",
        "inverse-surface": "#3f2c29",
        "inverse-on-surface": "#ffedea",

        background: "#fff8f7",
        "on-background": "#281715",

        outline: "#916f6a",
        "outline-variant": "#e6bdb7",

        error: "#ba1a1a",
        "error-container": "#ffdad6",
        "on-error": "#ffffff",
        "on-error-container": "#93000a",

        // Custom DMRC tokens
        "metro-grey": "#58595B",
        "sky-tint": "#F0F4F8",
        "success-green": "#28A745",

        // Dark mode surface overrides
        "dark-surface": "#1a0f0d",
        "dark-surface-container": "#2d1b18",
        "dark-on-surface": "#f0e0dc",
      },
      borderRadius: {
        DEFAULT: "0.25rem",
        lg: "0.5rem",
        xl: "0.75rem",
        "2xl": "1rem",
        full: "9999px",
      },
      fontFamily: {
        headline: ["Manrope", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
      fontSize: {
        "headline-xl": ["2.25rem", { lineHeight: "2.75rem", fontWeight: "700" }],
        "headline-lg": ["2rem", { lineHeight: "2.5rem", fontWeight: "600" }],
        "headline-md": ["1.5rem", { lineHeight: "2rem", fontWeight: "600" }],
        "headline-sm": ["1.25rem", { lineHeight: "1.75rem", fontWeight: "600" }],
        "body-lg": ["1.125rem", { lineHeight: "1.75rem", fontWeight: "400" }],
        "body-md": ["1rem", { lineHeight: "1.5rem", fontWeight: "400" }],
        "body-sm": ["0.875rem", { lineHeight: "1.25rem", fontWeight: "400" }],
        "label-lg": ["0.875rem", { lineHeight: "1.25rem", fontWeight: "600" }],
        "label-md": ["0.8125rem", { lineHeight: "1.125rem", fontWeight: "600" }],
        "label-sm": ["0.75rem", { lineHeight: "1rem", fontWeight: "600" }],
        "chat-bubble": ["1rem", { lineHeight: "1.5rem", fontWeight: "400" }],
      },
      spacing: {
        "bubble-padding-x": "1rem",
        "bubble-padding-y": "0.75rem",
        "container-margin": "1.25rem",
        "section-gap": "1.5rem",
        "stack-gap": "0.5rem",
        safe: "env(safe-area-inset-bottom)",
      },
      boxShadow: {
        "bot-bubble": "0 2px 8px rgba(0,0,0,0.06)",
        "user-bubble": "0 2px 8px rgba(180,0,6,0.12)",
        "input-panel": "0 8px 32px rgba(0,0,0,0.08)",
        "sidebar-card": "0 2px 12px rgba(0,0,0,0.06)",
      },
      animation: {
        "spring-in": "springIn 0.4s cubic-bezier(0.34,1.56,0.64,1) both",
        "fade-in": "fadeIn 0.3s ease both",
        "slide-up": "slideUp 0.3s cubic-bezier(0.4,0,0.2,1) both",
        "typing-dot": "typingDot 1.4s infinite both",
        namaste: "namaste 1.2s cubic-bezier(0.34,1.56,0.64,1) both",
        pulse: "pulse 2s cubic-bezier(0.4,0,0.6,1) infinite",
        shimmer: "shimmer 1.5s infinite",
      },
      keyframes: {
        springIn: {
          "0%": { opacity: "0", transform: "translateY(12px) scale(0.97)" },
          "100%": { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        typingDot: {
          "0%, 60%, 100%": { opacity: "0.2", transform: "translateY(0)" },
          "30%": { opacity: "1", transform: "translateY(-4px)" },
        },
        namaste: {
          "0%": { opacity: "0", transform: "scale(0) rotate(-20deg)" },
          "100%": { opacity: "1", transform: "scale(1) rotate(0deg)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      backdropBlur: {
        md: "12px",
      },
    },
  },
  plugins: [],
};

export default config;
