"use client";

import {
  createContext, useContext, useRef, useCallback,
  useState, useEffect, type ReactNode,
} from "react";
import {
  loadSessions, saveSession, deleteSession as dbDelete,
  renameSession as dbRename, toggleStar as dbStar,
  togglePin as dbPin, loadMessages, saveMessages,
  autoName, sortedSessions, type ChatSession,
} from "@/lib/chat-sessions";
import { generateId } from "@/lib/utils";
import type { ChatMessage } from "@/types";

/* ── Context shape ───────────────────────────────────────────────────── */

interface ChatContextValue {
  triggerQuery:      (msg: string) => void;
  registerSender:    (fn: (msg: string) => void) => void;
  sessions:          ChatSession[];
  activeSessionId:   string;
  activeMessages:    ChatMessage[];
  setActiveMessages: (msgs: ChatMessage[]) => void;
  switchSession:     (id: string) => void;
  newSession:        () => void;
  removeSession:     (id: string) => void;
  rename:            (id: string, name: string) => void;
  star:              (id: string) => void;
  pin:               (id: string) => void;
  hydrated:          boolean;  // ← prevents SSR/CSR mismatch
}

const ChatContext = createContext<ChatContextValue>({
  triggerQuery:      () => {},
  registerSender:    () => {},
  sessions:          [],
  activeSessionId:   "",
  activeMessages:    [],
  setActiveMessages: () => {},
  switchSession:     () => {},
  newSession:        () => {},
  removeSession:     () => {},
  rename:            () => {},
  star:              () => {},
  pin:               () => {},
  hydrated:          false,
});

/* ── Welcome message ─────────────────────────────────────────────────── */

function makeWelcome(): ChatMessage {
  return {
    id:        "welcome-diva",
    role:      "assistant",
    content:   "",
    // Use a fixed epoch for SSR — ChatInterface will re-hydrate
    timestamp: new Date(0),
  };
}

function makeSession(): ChatSession {
  const now = new Date().toISOString();
  return {
    id:        generateId(),
    name:      "New Chat",
    preview:   "",
    createdAt: now,
    updatedAt: now,
    starred:   false,
    pinned:    false,
  };
}

/* ── Provider ────────────────────────────────────────────────────────── */

export function ChatProvider({ children }: { children: ReactNode }) {
  const senderRef = useRef<((msg: string) => void) | null>(null);

  const [sessions,        setSessions]         = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId]  = useState<string>("");
  const [activeMessages,  setActiveMessagesRaw] = useState<ChatMessage[]>([makeWelcome()]);
  const [hydrated,        setHydrated]         = useState(false);

  /* ── Hydrate from localStorage (client only) ───────────────────────── */
  useEffect(() => {
    const stored = loadSessions();

    if (stored.length === 0) {
      const s = makeSession();
      saveSession(s);
      setSessions([s]);
      setActiveSessionId(s.id);
      setActiveMessagesRaw([makeWelcome()]);
    } else {
      const sorted = sortedSessions(stored);
      setSessions(stored);
      const first = sorted[0];
      setActiveSessionId(first.id);
      const msgs = loadMessages(first.id) as ChatMessage[];
      setActiveMessagesRaw(
        msgs.length
          ? msgs.map((m) => ({ ...m, timestamp: new Date(m.timestamp as unknown as string) }))
          : [makeWelcome()]
      );
    }
    setHydrated(true);
  }, []);

  /* ── Persist messages on change ────────────────────────────────────── */
  const setActiveMessages = useCallback(
    (msgs: ChatMessage[]) => {
      setActiveMessagesRaw(msgs);
      if (!activeSessionId) return;
      saveMessages(activeSessionId, msgs);

      const firstUser  = msgs.find((m) => m.role === "user");
      const firstReply = msgs.find((m) => m.role === "assistant" && m.id !== "welcome-diva");

      setSessions((prev) => {
        const updated = prev.map((s) => {
          if (s.id !== activeSessionId) return s;
          return {
            ...s,
            name:      s.name === "New Chat" && firstUser ? autoName(firstUser.content) : s.name,
            preview:   firstReply ? firstReply.content.replace(/[*#>`]/g, "").slice(0, 70) : s.preview,
            updatedAt: new Date().toISOString(),
          };
        });
        const target = updated.find((s) => s.id === activeSessionId);
        if (target) saveSession(target);
        return updated;
      });
    },
    [activeSessionId]
  );

  /* ── Switch session ────────────────────────────────────────────────── */
  const switchSession = useCallback((id: string) => {
    setActiveSessionId(id);
    const msgs = loadMessages(id) as ChatMessage[];
    setActiveMessagesRaw(
      msgs.length
        ? msgs.map((m) => ({ ...m, timestamp: new Date(m.timestamp as unknown as string) }))
        : [makeWelcome()]
    );
  }, []);

  /* ── New session ───────────────────────────────────────────────────── */
  const newSession = useCallback(() => {
    const s = makeSession();
    saveSession(s);
    setSessions((prev) => [s, ...prev]);
    setActiveSessionId(s.id);
    setActiveMessagesRaw([makeWelcome()]);
  }, []);

  /* ── Remove session ────────────────────────────────────────────────── */
  const removeSession = useCallback(
    (id: string) => {
      dbDelete(id);
      setSessions((prev) => {
        const remaining = prev.filter((s) => s.id !== id);
        if (id === activeSessionId) {
          if (remaining.length) {
            switchSession(sortedSessions(remaining)[0].id);
          } else {
            const s = makeSession();
            saveSession(s);
            setSessions([s]);
            setActiveSessionId(s.id);
            setActiveMessagesRaw([makeWelcome()]);
          }
        }
        return remaining;
      });
    },
    [activeSessionId, switchSession]
  );

  const rename = useCallback((id: string, name: string) => {
    dbRename(id, name);
    setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, name } : s)));
  }, []);

  const star = useCallback((id: string) => {
    const val = dbStar(id);
    setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, starred: val } : s)));
  }, []);

  const pin = useCallback((id: string) => {
    const val = dbPin(id);
    setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, pinned: val } : s)));
  }, []);

  const registerSender = useCallback((fn: (msg: string) => void) => {
    senderRef.current = fn;
  }, []);

  const triggerQuery = useCallback((msg: string) => {
    senderRef.current?.(msg);
  }, []);

  return (
    <ChatContext.Provider
      value={{
        triggerQuery, registerSender,
        sessions, activeSessionId, activeMessages, setActiveMessages,
        switchSession, newSession, removeSession, rename, star, pin,
        hydrated,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export const useChatContext = () => useContext(ChatContext);
