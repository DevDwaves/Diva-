export type MessageRole = "user" | "assistant" | "system";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  tier?: "static" | "escalation" | "llm" | "blocked";
}

export interface ChatRequestBody {
  messages: Array<{ role: MessageRole; content: string }>;
}

export interface SuggestionChip {
  id: string;
  label: string;
  prompt: string;
}

/** Re-exported so components don't need to import from lib/chat-sessions */
export type { ChatSession } from "@/lib/chat-sessions";
