"use client";

import { memo } from "react";
import { MessageBubble } from "@/components/chat/MessageBubble";
import type { ChatMessage } from "@/types";

export const MessageList = memo(function MessageList({
  messages,
}: {
  messages: ChatMessage[];
}) {
  const display = messages.filter((m) => m.id !== "welcome-diva");
  if (!display.length) return null;
  return (
    <div className="flex flex-col gap-1">
      {display.map((m) => (
        <MessageBubble key={m.id} message={m} />
      ))}
    </div>
  );
});
