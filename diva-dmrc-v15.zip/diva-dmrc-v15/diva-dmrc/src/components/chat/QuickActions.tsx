"use client";

import { memo, useCallback } from "react";
import { cn } from "@/lib/utils";

const ACTIONS = [
  {
    key: "leave",
    icon: "event_available",
    label: "Leave\nRules",
    prompt: "Casual leave aur Earned leave kitne din milte hain? Maternity leave ke baare mein bhi batao.",
    iconColor: "text-tertiary-container",
  },
  {
    key: "medical",
    icon: "local_hospital",
    label: "Medical\nBenefits",
    prompt: "Hospital mein room rent aur ICU charges kitna milta hai medical reimbursement mein?",
    iconColor: "text-primary",
  },
  {
    key: "ltc",
    icon: "flight_takeoff",
    label: "LTC\nTravel",
    prompt: "LTC kitne saal mein milta hai? Block year kya hota hai aur home town LTC kaise lein?",
    iconColor: "text-tertiary-container",
  },
  {
    key: "welfare",
    icon: "volunteer_activism",
    label: "Welfare\nFund",
    prompt: "Staff welfare fund se employees ko kya kya milta hai? Kya child birth gift milta hai?",
    iconColor: "text-tertiary-container",
  },
  {
    key: "hba",
    icon: "house",
    label: "House\nAdvance",
    prompt: "House building advance kitna mil sakta hai aur eligibility kya hai?",
    iconColor: "text-tertiary-container",
  },
  {
    key: "prce",
    icon: "badge",
    label: "Post\nRetirement",
    prompt: "Post retirement contractual engagement (PRCE) kya hai aur kaise milta hai?",
    iconColor: "text-tertiary-container",
  },
];

export const QuickActions = memo(function QuickActions({
  onAction,
}: {
  onAction: (prompt: string) => void;
}) {
  const handle = useCallback((prompt: string) => onAction(prompt), [onAction]);

  return (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
      {ACTIONS.map((a) => (
        <button
          key={a.key}
          type="button"
          onClick={() => handle(a.prompt)}
          className={cn(
            "flex flex-col items-center justify-center p-2.5 md:p-3",
            "bg-white rounded-xl shadow-sm border border-outline-variant/30",
            "hover:shadow-md hover:border-secondary hover:bg-surface-container-low",
            "active:scale-95 transition-all group"
          )}
          aria-label={a.label.replace("\n", " ")}
        >
          <span
            className={cn(
              "material-symbols-outlined text-[22px] mb-1",
              a.iconColor,
              "group-hover:scale-110 transition-transform"
            )}
            style={{ fontVariationSettings: "'FILL' 0" }}
          >
            {a.icon}
          </span>
          <span className="text-[10px] md:text-[11px] font-semibold text-on-surface text-center leading-tight whitespace-pre-line">
            {a.label}
          </span>
        </button>
      ))}
    </div>
  );
});
