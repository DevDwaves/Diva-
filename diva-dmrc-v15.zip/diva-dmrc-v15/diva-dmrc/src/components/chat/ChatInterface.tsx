"use client";

import {
  useState, useCallback, useRef, useEffect, useMemo, memo,
} from "react";
import { useChatContext }  from "@/context/ChatContext";
import { Header }          from "@/components/layout/Header";
import { MessageList }     from "@/components/chat/MessageList";
import { ChatInput }       from "@/components/chat/ChatInput";
import { QuickActions }    from "@/components/chat/QuickActions";
import { SuggestionChips } from "@/components/chat/SuggestionChips";
import { WelcomeScreen }   from "@/components/chat/WelcomeScreen";
import { generateId, formatTime } from "@/lib/utils";
import { DEFAULT_SUGGESTIONS } from "@/lib/system-prompt";

import type { ChatMessage } from "@/types";

/* ── Date helper — same output on server AND client, no locale dependency ── */
const DAYS   = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
function formatToday(): string {
  const d = new Date();
  return `${DAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

export const ChatInterface = memo(function ChatInterface() {
  const {
    registerSender,
    triggerQuery,
    activeMessages,
    setActiveMessages,
    newSession,
  } = useChatContext();

  const [streamContent, setStreamContent] = useState("");
  const [isStreaming,   setIsStreaming]    = useState(false);
  const [showSuggest,   setShowSuggest]    = useState(true);

  const abortRef    = useRef<AbortController | null>(null);
  const endRef      = useRef<HTMLDivElement>(null);
  const scrollRef   = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);

  // Hide suggestions once user has sent a message
  useEffect(() => {
    const hasUserMsg = activeMessages.some((m) => m.role === "user");
    if (hasUserMsg) setShowSuggest(false);
  }, [activeMessages]);

  /* ── Auto-scroll ─────────────────────────────────────────────────────── */
  const scrollBottom = useCallback(() => {
    if (!atBottomRef.current) return;
    requestAnimationFrame(() =>
      endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" })
    );
  }, []);

  useEffect(() => { scrollBottom(); }, [activeMessages, streamContent, scrollBottom]);

  const onScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  }, []);

  /* ── Build API message list (last 20, excluding welcome) ─────────────── */
  const apiMessages = useMemo(
    () =>
      activeMessages
        .filter((m) => m.id !== "welcome-diva")
        .slice(-20)
        .map(({ role, content }) => ({ role, content })),
    [activeMessages]
  );

  /* ── Send message ────────────────────────────────────────────────────── */
  const sendMessage = useCallback(
    async (input: string) => {
      const text = input.trim();
      if (!text || isStreaming) return;

      setShowSuggest(false);

      const userMsg: ChatMessage = {
        id:        generateId(),
        role:      "user",
        content:   text,
        timestamp: new Date(),
      };

      const updated = [...activeMessages, userMsg];
      setActiveMessages(updated);
      setIsStreaming(true);
      setStreamContent("");

      abortRef.current?.abort();
      abortRef.current = new AbortController();

      try {
        const res = await fetch("/api/chat", {
          method:  "POST",
          headers: { "Content-Type": "application/json" },
          body:    JSON.stringify({
            messages: [...apiMessages, { role: "user", content: text }],
          }),
          signal: abortRef.current.signal,
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Request failed." }));
          throw new Error(err.error ?? `HTTP ${res.status}`);
        }

        const reader  = res.body!.getReader();
        const decoder = new TextDecoder();
        let   accum   = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          accum += decoder.decode(value, { stream: true });
          setStreamContent(accum);
          scrollBottom();
        }

        const assistantMsg: ChatMessage = {
          id:        generateId(),
          role:      "assistant",
          content:   accum,
          timestamp: new Date(),
          tier: (res.headers.get("X-DIVA-Tier") ?? "llm") as ChatMessage["tier"],
        };

        setActiveMessages([...updated, assistantMsg]);
        setStreamContent("");
      } catch (err) {
        if ((err as Error).name === "AbortError") return;
        const msg = err instanceof Error ? err.message : "Something went wrong.";
        setActiveMessages([
          ...updated,
          {
            id:        generateId(),
            role:      "assistant",
            content:   `⚠️ **Error:** ${msg}\n\nPlease try again or contact **it.helpdesk@dmrc.org**.`,
            timestamp: new Date(),
          },
        ]);
        setStreamContent("");
      } finally {
        setIsStreaming(false);
      }
    },
    [isStreaming, activeMessages, apiMessages, setActiveMessages, scrollBottom]
  );

  /* ── Register sender in context (so Sidebar nav can trigger messages) ── */
  useEffect(() => {
    registerSender(sendMessage);
  }, [registerSender, sendMessage]);

  /* ── Stop streaming ──────────────────────────────────────────────────── */
  const stopStreaming = useCallback(() => {
    abortRef.current?.abort();
    if (streamContent) {
      setActiveMessages([
        ...activeMessages,
        {
          id:        generateId(),
          role:      "assistant",
          content:   streamContent + "\n\n*— Response stopped —*",
          timestamp: new Date(),
        },
      ]);
      setStreamContent("");
    }
    setIsStreaming(false);
  }, [streamContent, activeMessages, setActiveMessages]);

  /* ── New chat (calls context which resets session) ───────────────────── */
  const clearChat = useCallback(() => {
    abortRef.current?.abort();
    setStreamContent("");
    setIsStreaming(false);
    setShowSuggest(true);
    newSession();
  }, [newSession]);

  const isFirst = activeMessages.length === 1 && activeMessages[0]?.id === "welcome-diva";

  return (
    <div className="flex flex-col h-screen w-full relative overflow-hidden">
      <Header onClearChat={clearChat} />

      {/* Scroll container */}
      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="flex-1 overflow-y-auto thin-scrollbar pb-52 md:pb-48"
      >
        <div className="max-w-3xl mx-auto px-4 md:px-8 py-6">
          {/* Date divider — suppressHydrationWarning prevents server/client locale mismatch */}
          <div className="flex justify-center mb-6">
            <span
              suppressHydrationWarning
              className="px-3 py-1 bg-surface-variant text-on-surface-variant rounded-full text-xs font-semibold uppercase tracking-wider"
            >
              {formatToday()}
            </span>
          </div>

          {isFirst && <WelcomeScreen />}

          <MessageList messages={activeMessages} />

          {isStreaming && streamContent && (
            <BotBubble content={streamContent} streaming />
          )}
          {isStreaming && !streamContent && <TypingDots />}

          <div ref={endRef} className="h-1" />
        </div>
      </div>

      {/* Fixed bottom bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-sky-tint via-sky-tint/95 to-transparent pt-8 pb-4 px-4 md:px-8 z-20">
        <div className="max-w-3xl mx-auto flex flex-col gap-3">
          {showSuggest && (
            <SuggestionChips chips={DEFAULT_SUGGESTIONS} onSelect={sendMessage} />
          )}
          <QuickActions onAction={sendMessage} />
          <ChatInput onSend={sendMessage} onStop={stopStreaming} isStreaming={isStreaming} />
        </div>
      </div>
    </div>
  );
});

/* ── Shared sub-components ──────────────────────────────────────────────── */
function BotBubble({ content, streaming = false }: { content: string; streaming?: boolean }) {
  return (
    <div className="flex items-start gap-3 mt-4 spring-in">
      <img src="/diva-logo.png" alt="DIVA"
        className="w-9 h-9 rounded-full border border-outline-variant shadow-sm flex-shrink-0 mt-1 object-cover" />
      <div className="flex flex-col gap-1 max-w-[85%] md:max-w-[75%]">
        <span className="text-xs text-on-surface-variant ml-1 font-semibold">Diva</span>
        <div className={`bg-white text-on-surface px-4 py-3 rounded-2xl rounded-tl-sm bot-bubble-shadow prose-diva${streaming ? " streaming-cursor" : ""}`}>
          {content}
        </div>
      </div>
    </div>
  );
}

function TypingDots() {
  return (
    <div className="flex items-start gap-3 mt-4 spring-in">
      <img src="/diva-logo.png" alt="DIVA"
        className="w-9 h-9 rounded-full border border-outline-variant shadow-sm flex-shrink-0 mt-1 object-cover" />
      <div className="flex flex-col gap-1">
        <span className="text-xs text-on-surface-variant ml-1 font-semibold">Diva</span>
        <div className="bg-white px-4 py-3 rounded-2xl rounded-tl-sm bot-bubble-shadow flex items-center gap-1.5 h-10">
          <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
        </div>
      </div>
    </div>
  );
}
