"use client";

import { memo }            from "react";
import ReactMarkdown       from "react-markdown";
import remarkGfm           from "remark-gfm";
import { WELCOME_MESSAGE } from "@/lib/system-prompt";

export const WelcomeScreen = memo(function WelcomeScreen() {
  return (
    <div className="flex flex-col items-start gap-1 spring-in mb-2">
      <div className="flex justify-center w-full mb-4">
        <span
          className="text-5xl select-none"
          style={{ animation: "namaste 0.8s cubic-bezier(0.34,1.56,0.64,1) both" }}
          role="img"
          aria-label="Namaste"
        >
          🙏
        </span>
      </div>

      <div className="flex items-start gap-3 w-full">
        <img
          src="/diva-logo.png"
          alt="DIVA"
          className="w-9 h-9 rounded-full border border-outline-variant shadow-sm flex-shrink-0 mt-1 object-cover"
        />
        <div className="flex flex-col gap-1 max-w-[92%] md:max-w-[82%]">
          <span className="text-xs text-on-surface-variant ml-1 font-semibold">Diva</span>
          <div className="bg-white text-on-surface px-4 py-3 rounded-2xl rounded-tl-sm bot-bubble-shadow prose-diva">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{WELCOME_MESSAGE}</ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
});
