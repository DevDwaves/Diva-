"use client";

import { memo, useState, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm    from "remark-gfm";
import { cn, formatTime } from "@/lib/utils";
import type { ChatMessage }  from "@/types";

/* ── Clipboard with fallback for non-HTTPS / older browsers ─────────────── */
async function copyText(text: string): Promise<void> {
  // Method 1 — modern clipboard API (HTTPS / localhost)
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch {
      // fall through to method 2
    }
  }
  // Method 2 — legacy execCommand fallback
  const el = document.createElement("textarea");
  el.value = text;
  el.setAttribute("readonly", "");
  el.style.cssText = "position:absolute;left:-9999px;top:-9999px";
  document.body.appendChild(el);
  el.select();
  el.setSelectionRange(0, text.length); // mobile
  document.execCommand("copy");
  document.body.removeChild(el);
}

/* ── Copy button (always visible, not just on hover) ──────────────────── */
function CopyBtn({ text }: { text: string }) {
  const [state, setState] = useState<"idle" | "copied" | "error">("idle");

  const handleCopy = useCallback(async () => {
    try {
      await copyText(text);
      setState("copied");
    } catch {
      setState("error");
    } finally {
      setTimeout(() => setState("idle"), 2000);
    }
  }, [text]);

  return (
    <button
      type="button"
      onClick={handleCopy}
      title="Copy response"
      className={cn(
        "mt-2 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all",
        state === "idle"   && "text-metro-grey hover:text-secondary hover:bg-surface-container",
        state === "copied" && "text-success-green bg-green-50",
        state === "error"  && "text-error bg-red-50"
      )}
    >
      <span className="material-symbols-outlined text-[14px]">
        {state === "idle"   ? "content_copy" : state === "copied" ? "check_circle" : "error"}
      </span>
      {state === "idle" ? "Copy" : state === "copied" ? "Copied!" : "Failed"}
    </button>
  );
}

/* ── Message Bubble ───────────────────────────────────────────────────────── */
export const MessageBubble = memo(function MessageBubble({
  message,
}: {
  message: ChatMessage;
}) {
  const isUser = message.role === "user";

  /* ── User bubble ─────────────────────────────────────────────── */
  if (isUser) {
    return (
      <div className="flex justify-end mt-4 spring-in group">
        <div className="flex flex-col items-end gap-1 max-w-[85%] md:max-w-[72%]">
          <div className="bg-primary-container text-on-primary px-4 py-3 rounded-2xl rounded-tr-sm user-bubble-shadow text-base leading-relaxed">
            {message.content}
          </div>
          <span className="text-[11px] text-on-surface-variant opacity-0 group-hover:opacity-100 transition-opacity pr-1">
            {formatTime(message.timestamp)}
          </span>
        </div>
      </div>
    );
  }

  /* ── Bot bubble ──────────────────────────────────────────────── */
  return (
    <div className="flex items-start gap-3 mt-4 spring-in">
      <img
        src="/diva-logo.png"
        alt="DIVA"
        className="w-9 h-9 rounded-full border border-outline-variant shadow-sm flex-shrink-0 mt-1 object-cover"
        loading="lazy"
      />
      <div className="flex flex-col gap-1 max-w-[85%] md:max-w-[76%]">
        <span className="text-xs text-on-surface-variant ml-1 font-semibold">Diva</span>

        <div className="bg-white text-on-surface px-4 pt-3 pb-2 rounded-2xl rounded-tl-sm bot-bubble-shadow">
          {/* Markdown content */}
          <div className="prose-diva">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                a: ({ href, children }) => (
                  <a href={href} target="_blank" rel="noopener noreferrer">
                    {children}
                  </a>
                ),
                // Scrollable tables on mobile
                table: ({ children }) => (
                  <div className="overflow-x-auto -mx-1">
                    <table>{children}</table>
                  </div>
                ),
                code: ({
                  inline, className, children, ...props
                }: { inline?: boolean; className?: string; children?: React.ReactNode }) =>
                  inline ? (
                    <code className={className} {...props}>{children}</code>
                  ) : (
                    <code className={cn("block", className)} {...props}>{children}</code>
                  ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>

          {/* Copy button — always visible, below the text */}
          <div className="mt-1 border-t border-outline-variant/20 pt-1">
            <CopyBtn text={message.content} />
          </div>
        </div>

        <span className="text-[11px] text-on-surface-variant ml-1 opacity-60">
          {formatTime(message.timestamp)}
        </span>
      </div>
    </div>
  );
});
