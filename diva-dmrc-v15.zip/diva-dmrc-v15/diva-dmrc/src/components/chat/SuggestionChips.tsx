"use client";

import { memo } from "react";
import { cn } from "@/lib/utils";
import type { SuggestionChip } from "@/types";

export const SuggestionChips = memo(function SuggestionChips({
  chips,
  onSelect,
}: {
  chips: SuggestionChip[];
  onSelect: (prompt: string) => void;
}) {
  if (!chips.length) return null;
  return (
    <div className="flex flex-wrap gap-2 pl-1">
      {chips.map((chip) => (
        <button
          key={chip.id}
          type="button"
          onClick={() => onSelect(chip.prompt)}
          className={cn(
            "px-4 py-2 bg-surface-glass border border-secondary text-secondary",
            "rounded-full text-sm font-semibold",
            "hover:bg-secondary hover:text-on-secondary",
            "active:scale-95 transition-all shadow-sm spring-in"
          )}
        >
          {chip.label}
        </button>
      ))}
    </div>
  );
});
