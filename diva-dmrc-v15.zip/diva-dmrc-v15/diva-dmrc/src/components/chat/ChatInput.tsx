"use client";

/**
 * ChatInput — mic and attach removed (not functional).
 * Enter to send, Shift+Enter for new line.
 * Auto-resizes up to 5 lines.
 */

import { useRef, useState, useCallback, useEffect } from "react";
import { cn } from "@/lib/utils";

export function ChatInput({
  onSend,
  onStop,
  isStreaming,
  placeholder = "Ask anything about DMRC HR rules...",
}: {
  onSend:      (msg: string) => void;
  onStop:      () => void;
  isStreaming:  boolean;
  placeholder?: string;
}) {
  const [value, setValue] = useState("");
  const ref               = useRef<HTMLTextAreaElement>(null);
  const hasContent        = value.trim().length > 0;

  // Auto-resize
  const resize = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }, []);

  useEffect(() => { resize(); }, [value, resize]);

  const send = useCallback(() => {
    if (!hasContent || isStreaming) return;
    const msg = value.trim();
    setValue("");
    if (ref.current) ref.current.style.height = "auto";
    onSend(msg);
  }, [hasContent, isStreaming, value, onSend]);

  const onKey = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    },
    [send]
  );

  return (
    <div className="glass-panel rounded-2xl flex items-end px-4 py-2.5 shadow-input-panel gap-3">
      {/* Textarea */}
      <textarea
        ref={ref}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKey}
        placeholder={placeholder}
        rows={1}
        className={cn(
          "flex-1 bg-transparent border-none resize-none outline-none",
          "text-on-surface text-base leading-relaxed",
          "placeholder:text-metro-grey/60",
          "min-h-[2.25rem] max-h-[7.5rem] overflow-y-auto no-scrollbar py-1"
        )}
        autoComplete="off"
        spellCheck
        aria-label="Chat message input"
      />

      {/* Send / Stop */}
      {isStreaming ? (
        <button
          type="button"
          onClick={onStop}
          className="w-9 h-9 flex-shrink-0 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-primary/90 active:scale-90 shadow-sm transition-all"
          aria-label="Stop generating"
          title="Stop"
        >
          <span
            className="material-symbols-outlined text-[18px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            stop
          </span>
        </button>
      ) : (
        <button
          type="button"
          onClick={send}
          disabled={!hasContent}
          className={cn(
            "w-9 h-9 flex-shrink-0 rounded-full flex items-center justify-center",
            "shadow-sm active:scale-90 transition-all",
            hasContent
              ? "bg-primary text-on-primary hover:bg-primary/90"
              : "bg-metro-grey/20 text-metro-grey cursor-not-allowed"
          )}
          aria-label="Send message"
          title="Send (Enter)"
        >
          <span className="material-symbols-outlined text-[18px]">send</span>
        </button>
      )}
    </div>
  );
}
