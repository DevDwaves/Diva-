"use client";

import { memo }            from "react";
import { useChatContext }  from "@/context/ChatContext";

export const Header = memo(function Header({
  onClearChat,
}: {
  onClearChat?: () => void;
}) {
  const { sessions, activeSessionId } = useChatContext();
  const active = sessions.find((s) => s.id === activeSessionId);

  return (
    <header className="flex items-center justify-between px-5 md:px-8 py-4 bg-surface-glass backdrop-blur-md border-b border-outline-variant/30 z-30 flex-shrink-0">
      <div className="flex items-center gap-3 min-w-0">
        {/* Mobile logo */}
        <img
          src="/diva-logo.png"
          alt="DIVA"
          className="md:hidden w-9 h-9 rounded-full border border-outline-variant shadow-sm object-cover flex-shrink-0"
        />
        <div className="min-w-0">
          <h1 className="font-headline font-bold text-primary text-xl md:text-2xl tracking-tight truncate">
            How can I assist you today?
          </h1>
          {/* Show active session name as subtitle */}
          {active && active.name !== "New Chat" && (
            <p className="text-xs text-on-surface-variant truncate mt-0.5 hidden md:block">
              {active.name}
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        {/* System status */}
        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-surface-container-low rounded-full border border-outline-variant/40 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-success-green animate-pulse" />
          <span className="text-xs font-semibold text-on-surface-variant">System Optimal</span>
        </div>

        {/* New chat */}
        {onClearChat && (
          <button
            type="button"
            onClick={onClearChat}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-metro-grey hover:bg-surface-container hover:text-on-surface transition-all"
            title="New conversation"
          >
            <span className="material-symbols-outlined text-[18px]">edit_square</span>
            <span className="hidden sm:inline">New Chat</span>
          </button>
        )}
      </div>
    </header>
  );
});
