"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { useChatContext }   from "@/context/ChatContext";
import { sortedSessions }   from "@/lib/chat-sessions";
import { cn }               from "@/lib/utils";
import type { ChatSession } from "@/lib/chat-sessions";

const VISIBLE_LIMIT = 5;

const NAV_ITEMS = [
  { key: "home",     icon: "home",            label: "Home",          prompt: "" },
  { key: "leave",    icon: "event_available", label: "Leave Balance", prompt: "Casual leave, Earned leave, Maternity aur Paternity leave ke rules kya hain DMRC mein?" },
  { key: "medical",  icon: "local_hospital",  label: "Medical",       prompt: "Hospital mein room rent kitna milta hai aur medical reimbursement kaise hota hai?" },
  { key: "ltc",      icon: "flight_takeoff",  label: "LTC / Travel",  prompt: "LTC kitne saal mein milta hai? Block year kya hota hai aur home town travel kaise claim karein?" },
  { key: "support",  icon: "support_agent",   label: "Support",       prompt: "DMRC IT helpdesk aur HR department se kaise contact karein?" },
];

const QUICK_TOPICS = [
  { id: "qt1", label: "Maternity leave rules",         prompt: "Maternity leave kitne din ki hoti hai? Conditions kya hain?" },
  { id: "qt2", label: "Staff welfare fund benefits",   prompt: "Staff welfare fund se employees ko kya kya milta hai? Child birth gift kya hai?" },
  { id: "qt3", label: "Quarter allotment",             prompt: "DMRC staff quarters ka allotment kaise hota hai? Eligibility aur types kya hain?" },
  { id: "qt4", label: "Post-retirement (PRCE)",        prompt: "Post retirement contractual engagement (PRCE) kya hai, kaise milta hai aur kya benefits hain?" },
  { id: "qt5", label: "Recruitment age limit",         prompt: "DMRC mein recruitment ke liye age limit aur eligibility kya hai?" },
];

/* ── Session context menu ────────────────────────────────────────────────── */
function SessionMenu({ session, onClose }: { session: ChatSession; onClose: () => void }) {
  const { rename, star, pin, removeSession } = useChatContext();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft]     = useState(session.name);
  const menuRef               = useRef<HTMLDivElement>(null);
  const inputRef              = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) onClose();
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [onClose]);

  useEffect(() => { if (editing) inputRef.current?.focus(); }, [editing]);

  const submitRename = () => {
    if (draft.trim()) rename(session.id, draft.trim());
    setEditing(false); onClose();
  };

  if (editing) {
    return (
      <div className="absolute right-0 top-0 z-50 w-52 bg-white rounded-xl shadow-lg border border-outline-variant/40 p-2">
        <input
          ref={inputRef} value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") submitRename(); if (e.key === "Escape") { setEditing(false); onClose(); } }}
          className="w-full text-sm px-2 py-1.5 border border-secondary rounded-lg outline-none text-on-surface"
          maxLength={60}
        />
        <div className="flex gap-1 mt-1.5">
          <button onClick={submitRename} className="flex-1 py-1 text-xs font-semibold bg-secondary text-on-secondary rounded-lg">Save</button>
          <button onClick={() => { setEditing(false); onClose(); }} className="flex-1 py-1 text-xs font-semibold bg-surface-container text-on-surface rounded-lg">Cancel</button>
        </div>
      </div>
    );
  }

  return (
    <div ref={menuRef} className="absolute right-0 top-6 z-50 w-44 bg-white rounded-xl shadow-lg border border-outline-variant/40 py-1 overflow-hidden">
      {[
        { icon: "edit",    label: "Rename",                  onClick: () => setEditing(true),                    color: "" },
        { icon: session.starred ? "star_off" : "star",   label: session.starred ? "Unstar" : "Star",   onClick: () => { star(session.id); onClose(); }, color: session.starred ? "text-yellow-500" : "" },
        { icon: session.pinned  ? "keep_off" : "keep",  label: session.pinned  ? "Unpin"  : "Pin",   onClick: () => { pin(session.id);  onClose(); }, color: session.pinned  ? "text-secondary"  : "" },
      ].map((item) => (
        <button key={item.label} type="button" onClick={item.onClick}
          className={cn("w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-surface-container text-left", item.color || "text-on-surface")}>
          <span className={cn("material-symbols-outlined text-[16px]", item.color || "text-on-surface-variant")}>{item.icon}</span>
          {item.label}
        </button>
      ))}
      <div className="my-1 border-t border-outline-variant/20" />
      <button type="button" onClick={() => { removeSession(session.id); onClose(); }}
        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-surface-container text-error text-left">
        <span className="material-symbols-outlined text-[16px] text-error">delete</span>Delete
      </button>
    </div>
  );
}

/* ── Single session row ───────────────────────────────────────────────────── */
function SessionRow({ session }: { session: ChatSession }) {
  const { activeSessionId, switchSession } = useChatContext();
  const [menuOpen, setMenuOpen] = useState(false);
  const isActive = session.id === activeSessionId;

  return (
    <div className={cn("group relative flex items-center gap-2 px-2 py-2 rounded-xl cursor-pointer transition-all",
      isActive ? "bg-secondary/10 border border-secondary/30" : "hover:bg-surface-container")}>
      {session.pinned  && <span className="material-symbols-outlined text-[12px] text-secondary flex-shrink-0" style={{ fontVariationSettings: "'FILL' 1" }}>keep</span>}
      {!session.pinned && session.starred && <span className="material-symbols-outlined text-[12px] text-yellow-500 flex-shrink-0" style={{ fontVariationSettings: "'FILL' 1" }}>star</span>}
      {!session.pinned && !session.starred && <span className="material-symbols-outlined text-[14px] text-metro-grey/50 flex-shrink-0">chat_bubble_outline</span>}

      <button type="button" onClick={() => switchSession(session.id)} className="flex-1 text-left min-w-0">
        <p className={cn("text-sm font-medium truncate", isActive ? "text-secondary" : "text-on-surface")}>{session.name}</p>
        {session.preview && <p className="text-[11px] text-on-surface-variant truncate mt-0.5 leading-tight">{session.preview}</p>}
      </button>

      <button type="button" onClick={(e) => { e.stopPropagation(); setMenuOpen((v) => !v); }}
        className={cn("p-1 rounded-lg flex-shrink-0 transition-opacity opacity-0 group-hover:opacity-100 hover:bg-surface-variant text-on-surface-variant", menuOpen && "opacity-100 bg-surface-container")}
        aria-label="Chat options">
        <span className="material-symbols-outlined text-[16px]">more_vert</span>
      </button>

      {menuOpen && <SessionMenu session={session} onClose={() => setMenuOpen(false)} />}
    </div>
  );
}

/* ── Chat history section ─────────────────────────────────────────────────── */
function ChatHistory() {
  const { sessions, newSession } = useChatContext();
  const [showAll, setShowAll]   = useState(false);
  const sorted  = sortedSessions(sessions);
  const visible = showAll ? sorted : sorted.slice(0, VISIBLE_LIMIT);
  const extra   = sorted.length - VISIBLE_LIMIT;

  return (
    <div>
      <div className="flex items-center justify-between px-3 mb-1">
        <p className="text-[10px] font-bold text-metro-grey uppercase tracking-widest">Chat History</p>
        <button type="button" onClick={newSession}
          className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-lg text-[10px] font-semibold text-secondary hover:bg-secondary/10 transition-colors" title="New chat">
          <span className="material-symbols-outlined text-[14px]">add</span>New
        </button>
      </div>

      <div className="space-y-0.5">
        {visible.length === 0
          ? <p className="px-3 py-2 text-xs text-on-surface-variant italic">No history yet. Start chatting!</p>
          : visible.map((s) => <SessionRow key={s.id} session={s} />)
        }
      </div>

      {sorted.length > VISIBLE_LIMIT && (
        <button type="button" onClick={() => setShowAll((v) => !v)}
          className="w-full mt-1 flex items-center justify-center gap-1 py-1.5 text-xs font-semibold text-on-surface-variant hover:text-secondary hover:bg-surface-container rounded-xl transition-all">
          <span className="material-symbols-outlined text-[14px]">{showAll ? "keyboard_arrow_up" : "keyboard_arrow_down"}</span>
          {showAll ? "Show less" : `${extra} more chat${extra !== 1 ? "s" : ""}`}
        </button>
      )}
    </div>
  );
}

/* ── Main Sidebar ─────────────────────────────────────────────────────────── */
export function Sidebar() {
  const { triggerQuery, newSession } = useChatContext();
  const [activeNav, setActiveNav]   = useState("home");

  const handleNav = useCallback((key: string, prompt?: string) => {
    setActiveNav(key);
    if (key === "home") { newSession(); return; }
    if (prompt) triggerQuery(prompt);
  }, [triggerQuery, newSession]);

  return (
    <aside className="hidden md:flex flex-col w-72 flex-shrink-0 h-screen bg-surface-container-lowest border-r border-outline-variant/30 overflow-y-auto thin-scrollbar">

      {/* Brand */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-outline-variant/20">
        <div className="relative flex-shrink-0">
          <img src="/diva-logo.png" alt="DIVA" className="w-12 h-12 rounded-full border-2 border-outline-variant shadow-md object-cover" />
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-success-green rounded-full border-2 border-white" />
        </div>
        <div>
          <h2 className="font-headline text-base font-bold text-on-surface tracking-tight">DMRC Diva</h2>
          <p className="text-xs text-metro-grey font-medium">Employee Assistant</p>
          <p className="text-xs text-success-green font-semibold mt-0.5 flex items-center gap-1">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-success-green animate-pulse" />Online
          </p>
        </div>
      </div>

      {/* Nav */}
      <div className="flex-1 px-3 mt-3 space-y-0.5 overflow-y-auto thin-scrollbar">

        {/* Main nav items */}
        {NAV_ITEMS.map((item) => (
          <button key={item.key} type="button"
            onClick={() => handleNav(item.key, item.prompt)}
            className={cn("w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all text-left",
              activeNav === item.key
                ? "bg-secondary text-on-secondary shadow-sm"
                : "text-on-surface-variant hover:bg-surface-container hover:text-on-surface")}>
            <span className="material-symbols-outlined text-[20px]"
              style={{ fontVariationSettings: activeNav === item.key ? "'FILL' 1" : "'FILL' 0" }}>
              {item.icon}
            </span>
            {item.label}
          </button>
        ))}

        {/* Chat History */}
        <div className="pt-3 pb-1">
          <ChatHistory />
        </div>

        {/* Quick Topics */}
        <div className="pt-2">
          <p className="px-3 text-[10px] font-bold text-metro-grey uppercase tracking-widest mb-1.5">Quick Topics</p>
          <div className="space-y-0.5">
            {QUICK_TOPICS.map((qt) => (
              <button key={qt.id} type="button" onClick={() => triggerQuery(qt.prompt)}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-all text-left">
                <span className="material-symbols-outlined text-[15px] text-metro-grey flex-shrink-0">article</span>
                <span className="truncate text-[13px]">{qt.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-3 pb-4 pt-2 border-t border-outline-variant/20 mt-2 space-y-1">
        <button type="button"
          onClick={() => triggerQuery("DMRC HR Compendium ke saare chapters A se N tak kya kya cover karte hain? Ek table mein summary do.")}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-all text-left">
          <span className="material-symbols-outlined text-[18px]">menu_book</span>
          HR Compendium (A–N)
        </button>
        <button type="button"
          onClick={() => triggerQuery("DMRC ke conduct aur discipline rules kya hain? Misconduct par kya action hota hai?")}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-all text-left">
          <span className="material-symbols-outlined text-[18px]">gavel</span>
          Conduct & Discipline
        </button>
        <button type="button"
          onClick={() => triggerQuery("DMRC IT helpdesk aur HR se kaise contact karein? Grievance kaise raise karein?")}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-error hover:bg-error-container hover:text-on-error-container transition-all text-left">
          <span className="material-symbols-outlined text-[18px]">help</span>
          Get Help / Contact HR
        </button>
      </div>
    </aside>
  );
}
