"use client";

import { useState } from "react";
import { useChatContext } from "@/context/ChatContext";
import { cn }             from "@/lib/utils";

const TABS = [
  { key: "chat",    icon: "chat",            label: "Chat",    prompt: "" },
  { key: "leave",   icon: "event_available", label: "Leave",   prompt: "Casual leave, Earned leave, Maternity aur Paternity leave ke rules kya hain?" },
  { key: "ltc",     icon: "flight_takeoff",  label: "LTC",     prompt: "LTC kitne saal mein milta hai? Block year kya hota hai?" },
  { key: "chapters",icon: "menu_book",       label: "Chapters",prompt: "DMRC HR Compendium ke saare chapters A se N tak kya kya cover karte hain? Summary do." },
];

export function MobileNav() {
  const { triggerQuery, newSession } = useChatContext();
  const [active, setActive]         = useState("chat");

  function tap(key: string, prompt: string) {
    setActive(key);
    if (key === "chat") { newSession(); return; }
    if (prompt) triggerQuery(prompt);
  }

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-surface-glass backdrop-blur-md border-t border-outline-variant/30 shadow-lg">
      <div className="flex justify-around items-center h-16 px-2 pb-safe">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => tap(tab.key, tab.prompt)}
            className={cn(
              "flex flex-col items-center justify-center gap-0.5 flex-1 py-2 rounded-2xl transition-all active:scale-90",
              active === tab.key ? "text-primary" : "text-on-surface-variant hover:text-primary"
            )}
          >
            <span
              className="material-symbols-outlined text-[22px]"
              style={{ fontVariationSettings: active === tab.key ? "'FILL' 1" : "'FILL' 0" }}
            >
              {tab.icon}
            </span>
            <span className="text-[10px] font-semibold">{tab.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
