/**
 * DIVA Topic Guard — Full A-N scope
 * ====================================
 * Fast pre-filter that runs BEFORE the LLM call.
 * Blocks clearly off-topic queries instantly — no Groq tokens spent.
 * Word-boundary matching throughout to prevent substring false positives.
 */

const DMRC_SIGNALS = [
  // General
  "chapter","compendium","service rules","hr policy","hr rules",
  "policy","circular","guidelines","procedure","regulation","dmrc",
  // Chapter A
  "probation","confirmation","appointment","resignation","retire",
  "retirement","superannuation","transfer","posting","joining time",
  "surety bond","training bond","employment","deputation","apar",
  "appraisal","performance rating","office hours","working hours",
  "shift","roster","attendance","training","promotion","seniority",
  // Chapter B
  "conduct","discipline","suspension","misconduct","charge sheet",
  "inquiry","penalty","dismissal","termination","subsistence","gift","vigilance",
  // Chapter C
  "salary","pay scale","allowance","increment","bonus","grade",
  "ida scale","dearness allowance","hra","night duty","perks",
  "payslip","ctc","shifting allowance","birthday gift","wage",
  // Chapter D
  "ta/da","tour","lodging","hotel allowance","daily allowance",
  "travel allowance","transfer grant","ctg","transportation",
  "personal effects","travelling allowance","fare","journey",
  // Chapter E
  "medical","hospital","hospitalization","room rent","icu",
  "opd","outpatient","insurance","treatment","doctor","illness",
  "surgery","nursing home","cghs","ambulance","ailment",
  // Chapter F
  "leave","casual leave","earned leave","half pay leave","hpl",
  "maternity","paternity","child care leave","ccl","study leave",
  "extra ordinary leave","eol","quarantine leave","wriil",
  "leave encashment","commuted leave","sick leave",
  // Chapter G
  "house building advance","hba","home loan","construction",
  "mortgage","housing loan","ready built flat",
  // Chapter H
  "vehicle advance","car advance","motor car","two wheeler",
  // Chapter I
  "multi purpose advance","multipurpose advance","mpa",
  // Chapter J
  "recruitment","direct recruitment","age limit","cadre","qualification",
  "lateral induction","selection process","hiring","joining formality",
  // Chapter K
  "quarter","quarters","staff quarters","housing allotment",
  "accommodation","flat allotment","quarter type",
  // Chapter L
  "staff welfare fund","swf","welfare fund","child birth gift",
  "sports award","welfare grant",
  // Chapter M
  "prce","post retirement","contractual engagement","retainer",
  "re-employment","post retirement contract",
  // Chapter N
  "ltc","leave travel concession","block year","home town",
  "any place india","travel concession",
  // Admin
  "helpdesk","it support","password","ess","hrms","portal",
  "metro bhawan","academy","grievance","hr.helpdesk",
];

const OFF_TOPIC_PATTERNS: RegExp[] = [
  /\b(code|coding|program|programming|algorithm|function|class\s+method|variable|loop|array|sort|debug|compile|deploy|git\b|api\b|database|sql|nosql|mongodb|react\.?js|angular|vue\.?js|node\.?js|python|java\b|javascript|typescript|c\+\+|golang|rust|php|ruby|swift|kotlin|flutter|html|css|tailwind|next\.?js|webpack|docker|kubernetes)\b/i,
  /\b(equation|calculus|integral|derivative|matrix|theorem|physics|chemistry|biology|atom|molecule|gravity|quantum)\b/i,
  /\b(recipe|ingredient|cook\b|bake\b|movie|film\b|series|song\b|music|album|cricket|football|soccer|ipl\b|bcci|sport\b|actor|actress|celebrity|bollywood|hollywood|netflix)\b/i,
  /\b(world war|mughal|british empire|capital of|population of|currency of|president of|prime minister of(?! india)|continent|ocean|planet|solar system|galaxy|universe)\b/i,
  /\b(write (a |an )?(poem|story|essay|joke|letter|speech|blog|article|caption|tweet))\b/i,
  /\b(translate|grammar|spell check|synonym|antonym)\b/i,
  /\b(stock market|nse\b|bse\b|sensex|nifty|mutual fund|crypto|bitcoin|forex|investment advice)\b/i,
  /\b(astrology|horoscope|zodiac|tarot|numerology)\b/i,
  /\b(diet plan|gym\b|yoga\b|meditation)\b/i,
  /\b(merge sort|bubble sort|quick sort|binary search|linked list|time complexity|space complexity)\b/i,
];

export interface GuardResult {
  allowed: boolean;
  refusal?: string;
}

function normalise(text: string): string {
  return text.toLowerCase().trim();
}

function hasSignal(norm: string, signal: string): boolean {
  if (signal.includes(" ")) return norm.includes(signal);
  const re = new RegExp(`\\b${signal}\\b`, "i");
  return re.test(norm);
}

export function checkTopic(query: string): GuardResult {
  const norm = normalise(query);
  if (DMRC_SIGNALS.some((s) => hasSignal(norm, s))) return { allowed: true };
  if (OFF_TOPIC_PATTERNS.some((p) => p.test(norm))) {
    return { allowed: false, refusal: buildRefusal(query) };
  }
  return { allowed: true };
}

function buildRefusal(query: string): string {
  return `🚫 **Outside My Scope**

I'm **DIVA** — DMRC's HR Policy Assistant, trained on the **complete DMRC HR Compendium (Chapters A–N)**.

For **"${query.slice(0, 60)}${query.length > 60 ? "…" : ""}"** — please use a general-purpose assistant.

Anything about DMRC HR policy I can help with? 🙏`;
}
