/**
 * Chat Sessions Manager
 * =====================
 * Handles multi-session chat history stored in localStorage.
 * Each session = one conversation thread.
 */

export interface ChatSession {
  id: string;
  name: string;
  preview: string;       // first 60 chars of first AI reply
  createdAt: string;     // ISO — serialisable
  updatedAt: string;
  starred: boolean;
  pinned: boolean;
}

const SESSIONS_KEY  = "diva-sessions";
const MESSAGES_KEY  = (id: string) => `diva-msgs-${id}`;
const MAX_SESSIONS  = 30;

/* ── Storage helpers ──────────────────────────────────────────────────── */

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* quota */ }
}

function remove(key: string) {
  if (typeof window === "undefined") return;
  try { localStorage.removeItem(key); } catch { /* noop */ }
}

/* ── Public API ────────────────────────────────────────────────────────── */

export function loadSessions(): ChatSession[] {
  return read<ChatSession[]>(SESSIONS_KEY, []);
}

export function saveSession(session: ChatSession) {
  const all = loadSessions();
  const idx = all.findIndex((s) => s.id === session.id);
  if (idx >= 0) {
    all[idx] = session;
  } else {
    all.unshift(session); // newest first
  }
  // Keep only latest MAX_SESSIONS
  write(SESSIONS_KEY, all.slice(0, MAX_SESSIONS));
}

export function deleteSession(id: string) {
  const all = loadSessions().filter((s) => s.id !== id);
  write(SESSIONS_KEY, all);
  remove(MESSAGES_KEY(id));
}

export function renameSession(id: string, name: string) {
  const all = loadSessions();
  const s   = all.find((s) => s.id === id);
  if (s) { s.name = name.trim().slice(0, 60) || s.name; }
  write(SESSIONS_KEY, all);
}

export function toggleStar(id: string): boolean {
  const all = loadSessions();
  const s   = all.find((s) => s.id === id);
  if (!s) return false;
  s.starred = !s.starred;
  write(SESSIONS_KEY, all);
  return s.starred;
}

export function togglePin(id: string): boolean {
  const all = loadSessions();
  const s   = all.find((s) => s.id === id);
  if (!s) return false;
  s.pinned = !s.pinned;
  write(SESSIONS_KEY, all);
  return s.pinned;
}

/** Load messages for a session */
export function loadMessages(id: string): unknown[] {
  return read<unknown[]>(MESSAGES_KEY(id), []);
}

/** Save messages for a session */
export function saveMessages(id: string, messages: unknown[]) {
  write(MESSAGES_KEY(id), messages.slice(-60));
}

/** Generate a tidy session name from the first user message */
export function autoName(firstUserMsg: string): string {
  const clean = firstUserMsg.replace(/[^a-zA-Z0-9\s]/g, " ").trim();
  const words = clean.split(/\s+/).slice(0, 6).join(" ");
  return words.length > 2 ? words : "New Chat";
}

/** Build a sorted list: pinned first, then starred, then by updatedAt */
export function sortedSessions(sessions: ChatSession[]): ChatSession[] {
  return [...sessions].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    if (a.starred !== b.starred) return a.starred ? -1 : 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
}
