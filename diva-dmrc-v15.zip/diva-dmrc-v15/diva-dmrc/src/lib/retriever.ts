/**
 * DIVA Retriever — TF-IDF RAG over real DMRC HR Compendium text
 * =================================================================
 * Source: Chapters A–N (official pages 1–582), extracted directly
 * from the PDF — 2,339 real chunks, zero TOC pollution. No paraphrasing
 * at this stage (paraphrasing happens later, by the LLM, using these
 * as ground truth).
 *
 * Chapters covered:
 *  A — General Conditions of Service Rules
 *  B — Conduct, Discipline & Appeal Rules
 *  C — Pay & Allowances Rules
 *  D — TA/DA & Transportation Rules
 *  E — Medical Attendance Rules
 *  F — Leave Rules
 *  G — House Building Advance Rules
 *  H — Vehicle Advance Rules
 *  I — Multi-Purpose Advance Rules
 *  J — Recruitment Rules
 *  K — DMRC Housing Allotment Rules
 *  L — Staff Welfare Fund Rules
 *  M — Post Retirement Contractual Engagement (PRCE) Rules
 *  N — Leave Travel Concession Rules
 *
 * Why TF-IDF instead of plain keyword counting:
 * Common words ("allowance", "rates", "charges") appear in almost
 * every paragraph and would dominate a naive sum-based score.
 * TF-IDF down-weights common words and up-weights rare, specific
 * terms (e.g. "lodging", "mgr", "superannuation", "PRCE", "LTC")
 * — so the chunk that actually answers the question ranks first.
 *
 * Why word-boundary matching:
 * Old bug — query "hotel" falsely matched a keyword "el" via plain
 * substring search ("hotel".includes("el") === true). Every match
 * here uses \b regex boundaries, so that class of bug is impossible.
 *
 * Why a synonym map:
 * No stemming is used, so "contract" never matches "contractual" by
 * default. The synonym map bridges these gaps explicitly (e.g.
 * contract→contractual/engagement) rather than adding a stemmer,
 * which keeps the matcher fast and predictable.
 */

import chunksData from "@/data/hr-chunks.json";

interface Chunk {
  chapter: string;
  text: string;
}

const CORPUS: Chunk[] = chunksData as Chunk[];
const N = CORPUS.length;

// ── Stop words — generic words with no retrieval signal ─────────────────
const STOP = new Set([
  "the","a","an","is","are","was","were","be","been","being","have",
  "has","had","do","does","did","will","would","could","should","may",
  "might","shall","can","need","must","to","of","in","on","at","by",
  "for","with","about","as","from","or","and","but","if","not","this",
  "that","it","its","i","my","me","we","our","you","your","what","when",
  "where","who","how","which","dmrc","employee","employees","rules",
  "rule","chapter","tell","please","know","want","get","give",
]);

const MIN_TOKEN_LEN = 3;

// ── Synonym map — bridges casual phrasing & missing stemming ────────────
const SYNONYMS: Record<string, string[]> = {
  manager: ["mgr"],
  hotel: ["lodging"], lodging: ["hotel"],
  allowance: ["charges"], allowances: ["charges"],
  retire: ["superannuation"], retirement: ["superannuation"],
  resign: ["resignation"],
  salary: ["pay", "basic", "scale", "ida"], pay: ["salary", "basic", "scale", "ida"],
  // Pay scale / classification synonyms
  payscale: ["pay", "scale", "ida", "classification"],
  scale: ["pay", "ida", "salary"],
  grade: ["scale", "pay", "classification", "category"],
  designation: ["grade", "scale", "classification"],
  classification: ["grade", "scale", "category", "ida"],
  band: ["scale", "pay", "ida"],
  loan: ["advance"], advance: ["loan"],
  car: ["vehicle"], bike: ["vehicle", "motorcycle"],
  hospital: ["treatment", "medical"], doctor: ["medical"],
  pregnant: ["maternity"], pregnancy: ["maternity"],
  child: ["children"], kid: ["child", "children"],
  house: ["hba", "building"], home: ["house", "hba"],
  sick: ["illness", "medical"], ill: ["illness"],
  contract: ["contractual", "engagement"], engage: ["engagement", "contractual"],
  mpa: ["multipurpose", "multi"],
  quarter: ["quarters", "accommodation"], quarters: ["quarter", "accommodation"],
  welfare: ["welfare fund", "swf"],
};

// Grade abbreviations used throughout the PDF tables (MD, GM, AM, etc.)
const GRADE_PATTERN = /\b(MD|TMM|ED|CGM|SGM|GM|DGM|JGM|AGM|AM|HOD)\b/gi;

function baseTokens(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= MIN_TOKEN_LEN && !STOP.has(w));
}

function extractGrades(text: string): string[] {
  const matches = text.match(GRADE_PATTERN) ?? [];
  return matches.map((g) => g.toLowerCase());
}

function queryTokens(query: string): Set<string> {
  const base = baseTokens(query);
  const expanded = new Set(base);
  for (const t of base) {
    if (SYNONYMS[t]) SYNONYMS[t].forEach((s) => expanded.add(s));
  }
  extractGrades(query).forEach((g) => expanded.add(g));
  return expanded;
}

function wordBoundaryMatch(token: string, text: string): boolean {
  const re = new RegExp(`\\b${token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
  return re.test(text);
}

// ── Build IDF index once at module load (cached across warm invocations) ──
const chunkTokenSets: Set<string>[] = [];
const docFreq = new Map<string, number>();

for (const chunk of CORPUS) {
  const toks = new Set(baseTokens(chunk.text));
  extractGrades(chunk.text).forEach((g) => toks.add(g));
  chunkTokenSets.push(toks);
  for (const t of toks) {
    docFreq.set(t, (docFreq.get(t) ?? 0) + 1);
  }
}

function idf(token: string): number {
  const df = docFreq.get(token) ?? 0;
  return Math.log(N / (1 + df)) + 1;
}

// ── Chapter-topic boost — mild secondary signal ──────────────────────────
// Maps query intent → the chapter whose NAME contains that key.
function chapterBoost(query: string, chapter: string): number {
  const q = query.toLowerCase();
  const c = chapter.toLowerCase();

  const hints: [RegExp, string][] = [
    // Chapter F — Leave Rules
    [/\bleave\b|\bcasual\b|\bmaternity\b|\bpaternity\b|\bccl\b|\bchild care\b|\bstudy leave\b|\bhpl\b|\bhalf pay\b|\bextra ordinary\b|\bquarantine\b|\bwriil\b|\bencashment\b/i, "leave rules"],
    // Chapter C — Pay & Allowances
    [/\bpay\b|\ballowance\b|\bsalary\b|\bhra\b|\bnight duty\b|\bincrement\b|\bperks\b|\bdearness\b/i, "pay & allow"],
    // Chapter B — Conduct & Discipline
    [/\bconduct\b|\bdiscipline\b|\bsuspension\b|\bmisconduct\b|\bpenalty\b|\bcharge sheet\b|\bgift\b/i, "conduct"],
    // Chapter D — TA/DA
    [/\btour\b|\btravel\b|\bhotel\b|\blodging\b|\btransfer grant\b|\bctg\b/i, "ta/da"],
    // Chapter E — Medical
    [/\bmedical\b|\bhospital\b|\broom rent\b|\bicu\b|\bopd\b|\binsurance\b|\btreatment\b|\bdoctor\b|\bsick\b|\billness\b/i, "medical"],
    // Chapter G — House Building Advance
    [/\bhba\b|\bhouse building\b|\bhome loan\b|\bconstruction\b|\bmortgage\b/i, "house building"],
    // Chapter H — Vehicle Advance
    [/\bvehicle\b|\bcar\b|\bbike\b|\bmotorcycle\b|\bown.{0,5}vehicle\b/i, "vehicle"],
    // Chapter I — Multi-Purpose Advance
    [/\bmulti.?purpose\b|\bmpa\b/i, "multi-purpose"],
    // Chapter J — Recruitment
    [/\brecruitment\b|\bage limit\b|\bdirect recruit\b|\bcadre\b|\bapplicant\b|\bjoining formality\b/i, "recruitment"],
    // Chapter K — Housing Allotment
    [/\bquarter\b|\baccommodation\b|\bhousing allot\b|\bstaff quarter\b/i, "housing allot"],
    // Chapter L — Staff Welfare Fund
    [/\bwelfare\b|\bswf\b/i, "welfare fund"],
    // Chapter M — Post Retirement Contractual Engagement
    [/\bprce\b|\bpost retirement\b|\bretainer\b|\bre-?employ/i, "post retirement"],
    // Chapter N — Leave Travel Concession
    [/\bltc\b|\bleave travel\b|\bhome town\b|\bblock year\b/i, "leave travel"],
    // Chapter A — General Conditions (also classification / pay scale table)
    [/\bprobation\b|\btransfer\b|\bresign\b|\bretire\b|\bapar\b|\bappraisal\b|\btraining\b|\bsuperannuation\b|\bjoining time\b|\bseniority\b|\bclassification\b|\bida scale\b|\bunskilled\b|\bsemi-?skilled\b|\bmaintainer\b/i, "general conditions"],
    // Chapter A + C — Pay scale / grade classification lookup
    [/\bpay.?scale\b|\bpayscale\b|\bida.?scale\b|\bgrade.{0,10}pay\b|\bpay.{0,10}grade\b|\bdesignation.{0,15}pay\b|\bsalary.{0,10}scale\b|\bscale.{0,10}salary\b|\bscale.{0,10}pay\b|\bwhat is.{0,20}pay\b|\bhow much.{0,20}salary\b/i, "general conditions"],
    [/\bpay.?scale\b|\bpayscale\b|\bida.?scale\b|\bgrade.{0,10}pay\b|\bpay.{0,10}grade\b|\bdesignation.{0,15}pay\b|\bsalary.{0,10}scale\b|\bscale.{0,10}salary\b|\bscale.{0,10}pay\b|\bwhat is.{0,20}pay\b|\bhow much.{0,20}salary\b/i, "pay & allow"],
  ];

  for (const [pattern, key] of hints) {
    if (pattern.test(q) && c.includes(key)) return 1.4;
  }
  return 1;
}

function scoreChunk(qTokens: Set<string>, chunkIdx: number, chunk: Chunk): number {
  const cTokenSet = chunkTokenSets[chunkIdx];
  const cText = chunk.text.toLowerCase();
  let s = 0;
  for (const tok of qTokens) {
    if (cTokenSet.has(tok) || wordBoundaryMatch(tok, cText)) {
      s += idf(tok);
    }
  }
  return s;
}

/** Retrieve top-N most relevant chunks for a query (TF-IDF ranked) */
export function retrieve(query: string, topN = 8): Chunk[] {
  const qTokens = queryTokens(query);
  if (!qTokens.size) return [];

  const scored = CORPUS.map((c, i) => ({
    chunk: c,
    score: scoreChunk(qTokens, i, c) * chapterBoost(query, c.chapter),
  }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topN);

  return scored.map((x) => x.chunk);
}

// ── Pay scale / classification detection ─────────────────────────────────
// When the query is about pay scale or grade of a designation, we inject
// the FULL classification table directly so the LLM never has to guess.
const PAY_SCALE_PATTERN = /pay.?scale|payscale|ida scale|salary.*scale|scale.*salary|what.*pay|kitna.*pay|pay.*kitna|grade.*pay|designation.*salary|how much.*salary|salary.*designation|vetan|tankhwa/i;

const CLASSIFICATION_TABLE = `CLASSIFICATION OF EMPLOYEES — DMRC HR Compendium, Chapter A, Section 1
(Also repeated in Chapter C — Pay & Allowances Rules)

NON-EXECUTIVE EMPLOYEES (IDA Scales):
Sr.No | Category                  | IDA Scale (Rs.)  | Status
1     | Unskilled                 | 16000–50000      | Non-Supervisor
2     | Semi-skilled              | 20000–60000      | Non-Supervisor
3     | Skilled Maintainer        | 25000–80000      | Non-Supervisor
4     | Maintainers and Assistants| 35000–110000     | Non-Supervisor
5     | Supervisor-II             | 37000–115000**   | Supervisor
6     | Supervisor-I              | 40000–125000**   | Supervisor
7     | Sr. Supervisors-II        | 46000–145000**   | Supervisor
8     | Sr. Supervisor-I          | 50000–160000     | Supervisor

EXECUTIVE EMPLOYEES (IDA Scales):
Sr.No | Category                                        | IDA Scale (Rs.)  | Status
1     | Asstt. Manager (AM)                             | 50000–160000     | Executive
2     | Manager                                         | 60000–180000     | Executive
3     | Dy. General Manager (DGM)                       | 70000–200000     | Executive
4     | Sr. Dy. General Manager (Sr. DGM)               | 80000–220000     | Executive
5     | Jt. General Manager (JGM)                       | 90000–240000     | Executive
6     | Addl. General Manager / Sr. Addl. General Manager* | 100000–260000 | Executive
7     | General Manager / Sr. General Manager / Chief General Manager* | 120000–280000 | Executive
8     | Executive Director (ED)                         | 150000–300000    | Executive
9     | Director                                        | 180000–340000    | Functional BOD
10    | Managing Director (MD)                          | 200000–370000    | Functional BOD

* Entitled for special pay of Rs.2,500/- p.m.
** Time bound promotion for non-supervisor to grades operated at Supervisor level. Work profile remains unchanged; certain service benefits extended at par with supervisors. Supervisory pay scales are also operated in non-supervisory categories on time-bound promotions.`;

/** Format retrieved chunks as SOURCE TEXT context block for the LLM */
export function buildContext(query: string): string {
  const results = retrieve(query);
  if (!results.length && !PAY_SCALE_PATTERN.test(query)) return "";

  const lines = results.map(
    (c, i) => `[${i + 1}] (${c.chapter})\n${c.text.trim()}`
  );

  // For pay scale queries, always prepend the authoritative classification table
  // as [0] so the LLM sees it first and uses the exact rows.
  const payScalePrefix = PAY_SCALE_PATTERN.test(query)
    ? `[0] (A - General Conditions of Service Rules — Classification Table)\n${CLASSIFICATION_TABLE}\n\n`
    : "";

  return `\n\n---\nSOURCE TEXT FROM DMRC HR COMPENDIUM (Chapters A-N, official pages 1-582). This is your ONLY source of facts — use it to answer, but explain in your own simple words:\n${payScalePrefix}${lines.join(
    "\n\n"
  )}\n---\n`;
}
