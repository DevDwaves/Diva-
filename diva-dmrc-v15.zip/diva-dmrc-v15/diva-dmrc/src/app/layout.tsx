import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DIVA — DMRC Intelligent Virtual Assistant",
  description:
    "Internal AI assistant for DMRC employees. Look up employee info, check leave, payroll, SOPs, and more.",
  applicationName: "DIVA",
  keywords: ["DMRC", "Delhi Metro", "employee assistant", "AI chatbot", "DIVA"],
  robots: "noindex, nofollow", // Internal app — not for search engines
  manifest: "/manifest.json",
  icons: {
    icon: "/diva-logo.png",
    apple: "/diva-logo.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#b40006",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Preconnect for faster font loading — performance win */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Manrope:wght@600;700;800&display=swap"
          rel="stylesheet"
        />
        {/* Material Symbols — for icons matching the original design */}
        <link
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&display=block"
          rel="stylesheet"
        />
      </head>
      <body className="bg-sky-tint">{children}</body>
    </html>
  );
}
