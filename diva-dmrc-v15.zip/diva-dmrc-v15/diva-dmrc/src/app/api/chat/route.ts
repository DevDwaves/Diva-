/**
 * POST /api/chat — DIVA Router (RAG-only, no static knowledge base)
 *
 * Tier 0  OFF-TOPIC  → instant refusal
 * Tier 1  RAG + LLM  → retrieve real PDF chunks (Chapters A-D) → Groq streams answer
 *
 * Why no static Tier-1 anymore:
 * The old hand-written knowledge base used substring keyword matching,
 * which caused false positives (e.g. "hotel" matching keyword "el" for
 * Earned Leave). RAG retrieval against real PDF text with word-boundary
 * matching is both more accurate AND simpler — one less layer to maintain.
 */

import { NextRequest, NextResponse } from "next/server";
import Groq from "groq-sdk";
import { checkTopic }        from "@/lib/topic-guard";
import { buildContext }      from "@/lib/retriever";
import { buildSystemPrompt } from "@/lib/system-prompt";
import type { ChatRequestBody } from "@/types";

const groq       = new Groq({ apiKey: process.env.GROQ_API_KEY });
const MODEL      = process.env.GROQ_MODEL    ?? "llama-3.3-70b-versatile";
const MAX_TOKENS = parseInt(process.env.GROQ_MAX_TOKENS ?? "800", 10); // room for structured scenario answers

/* ── Rate limiter ──────────────────────────────────────────────────────── */
const rateMap    = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = parseInt(process.env.RATE_LIMIT_MAX ?? "60", 10);

function checkRate(ip: string): boolean {
  const now = Date.now();
  const e   = rateMap.get(ip);
  if (!e || now > e.resetAt) { rateMap.set(ip, { count: 1, resetAt: now + 60_000 }); return true; }
  if (e.count >= RATE_LIMIT) return false;
  e.count++; return true;
}

function sanitize(t: string) {
  return t.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi,"").replace(/<[^>]+>/g,"").trim().slice(0, 2000);
}

function streamText(text: string, tier = "static"): Response {
  const enc = new TextEncoder();
  return new Response(
    new ReadableStream({
      async start(ctrl) {
        for (let i = 0; i < text.length; i += 30) {
          ctrl.enqueue(enc.encode(text.slice(i, i + 30)));
          await new Promise(r => setTimeout(r, 3));
        }
        ctrl.close();
      },
    }),
    { status: 200, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store", "X-DIVA-Tier": tier } }
  );
}

/* ── Main handler ──────────────────────────────────────────────────────── */
export async function POST(req: NextRequest) {
  if (!process.env.GROQ_API_KEY) {
    return NextResponse.json({ error: "GROQ_API_KEY not set in .env.local" }, { status: 500 });
  }

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "anon";
  if (!checkRate(ip)) return NextResponse.json({ error: "Too many requests." }, { status: 429 });

  let body: ChatRequestBody;
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Invalid JSON." }, { status: 400 }); }

  const { messages } = body;
  if (!Array.isArray(messages) || !messages.length)
    return NextResponse.json({ error: "messages required." }, { status: 400 });

  const sanitized = messages.map(m => ({ role: m.role as "user"|"assistant", content: sanitize(m.content) }));
  const lastUser  = [...sanitized].reverse().find(m => m.role === "user")?.content ?? "";

  /* Tier 0 — Off-topic block (instant, no Groq call) */
  const guard = checkTopic(lastUser);
  if (!guard.allowed) return streamText(guard.refusal!, "blocked");

  /* Tier 1 — RAG: retrieve real PDF chunks, stream answer via Groq */
  const sourceContext = buildContext(lastUser);
  const systemPrompt  = buildSystemPrompt(sourceContext);

  let stream: Awaited<ReturnType<typeof groq.chat.completions.create>>;
  try {
    stream = await groq.chat.completions.create({
      model:       MODEL,
      max_tokens:  MAX_TOKENS,
      temperature: 0.05,   // near-zero — minimize creative drift from source text
      top_p:       0.85,
      stream:      true,
      messages: [
        { role: "system", content: systemPrompt },
        ...sanitized.slice(-10),
      ],
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Groq API error.";
    console.error("[DIVA]", msg);
    return NextResponse.json({ error: msg }, { status: 502 });
  }

  const enc = new TextEncoder();
  return new Response(
    new ReadableStream({
      async start(ctrl) {
        try {
          for await (const chunk of stream) {
            const d = chunk.choices[0]?.delta?.content;
            if (d) ctrl.enqueue(enc.encode(d));
            if (chunk.choices[0]?.finish_reason === "stop") break;
          }
        } finally { ctrl.close(); }
      },
    }),
    { status: 200, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store", "X-DIVA-Tier": "llm" } }
  );
}
