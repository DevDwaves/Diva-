import { ChatProvider } from "@/context/ChatContext";
import { ChatInterface } from "@/components/chat/ChatInterface";
import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";

export default function Home() {
  return (
    <ChatProvider>
      <div className="flex h-screen w-full overflow-hidden bg-sky-tint">
        <Sidebar />
        <div className="flex flex-col flex-1 min-w-0 h-screen">
          <ChatInterface />
        </div>
        <MobileNav />
      </div>
    </ChatProvider>
  );
}
