# DIVA — DMRC Intelligent Virtual Assistant

<div align="center">
  <img src="public/diva-logo.png" width="100" alt="DIVA Logo" />
  <h3>RAG-powered HR policy assistant for DMRC employees</h3>
  <p>Next.js 15 · Groq · TypeScript · Tailwind CSS</p>
</div>

---

## Knowledge Base — All 14 Chapters (Complete Compendium)

| Chapter | Topic | Source Pages | Chunks |
|---|---|---|---|
| **A** | General Conditions of Service Rules | 1–95 | 439 |
| **B** | Conduct, Discipline & Appeal Rules | 96–168 | 276 |
| **C** | Pay & Allowances Rules | 169–214 | 193 |
| **D** | TA/DA & Transportation Rules | 215–240 | 86 |
| **E** | Medical Attendance Rules | 242–304 | 253 |
| **F** | Leave Rules | 305–353 | 223 |
| **G** | House Building Advance Rules | 354–429 | 293 |
| **H** | Vehicle Advance Rules | 430–453 | 76 |
| **I** | Multi-Purpose Advance Rules | 454–465 | 31 |
| **J** | Recruitment Rules | 466–479 | 57 |
| **K** | DMRC Housing Allotment Rules | 480–510 | 111 |
| **L** | Staff Welfare Fund Rules | 511–527 | 53 |
| **M** | Post Retirement Contractual Engagement Rules | 528–541 | 49 |
| **N** | Leave Travel Concession Rules | 542–582 | 199 |
| | **TOTAL** | **Pages 1–582** | **2,339 chunks** |

Extracted directly from the official PDF — zero Table-of-Contents pollution, verified by automated scan.

---

## Architecture — RAG, not hand-written FAQs

```
User asks a question
        ↓
┌──────────────────────────────────────────┐
│ Tier 0 — Topic Guard (~0ms)              │
│ Off-topic? → instant refusal, no LLM    │
└───────────────┬──────────────────────────┘
                ↓
┌──────────────────────────────────────────┐
│ Tier 1 — TF-IDF Retrieval (~1ms)         │
│ Score all 2,339 chunks against the query │
│ Return top 8 most relevant real PDF text │
└───────────────┬──────────────────────────┘
                ↓
┌──────────────────────────────────────────┐
│ Tier 2 — Groq LLM Streaming              │
│ Paraphrase retrieved chunks into a       │
│ short, grounded, conversational answer   │
│ temperature: 0.05 (near-deterministic)   │
└──────────────────────────────────────────┘
```

---

## Precision Rules (enforced in system prompt)

After evaluation feedback, DIVA's prompt was tightened to:
- **Ban hedging language** — no "might be eligible," "typically," "usually"
- **Refuse to guess** — honest "not specified" instead of generic HR reasoning
- **Structured scenario answers** — Rule → Provision → Application → Conclusion
- **Exact figures only** — numbers, durations, grade names never rounded

---

## Tech Stack

```
Frontend:  Next.js 15 · React 19 · TypeScript · Tailwind CSS 3
AI:        Groq API (llama-3.3-70b-versatile, temp: 0.05)
Retrieval: TF-IDF over 2,339 real PDF chunks (word-boundary matched)
Storage:   Browser localStorage (chat sessions with rename/star/pin/delete)
Deploy:    Vercel (bom1 / Mumbai region)
```

---

## Setup

```bash
npm install && npm run dev
```

`.env.local` is included. To use your own Groq key:
```
GROQ_API_KEY=gsk_your_key_here
GROQ_MODEL=llama-3.3-70b-versatile
GROQ_MAX_TOKENS=800
```
